﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AdventureGame : MonoBehaviour
{

    [SerializeField] Text textComponent;             // textComponent available inside the inspector so changes can be made there
    [SerializeField] State startingState;            // startingState available inside the inspector

    //int[] oddNumbers = { 1, 3, 5, 7, 9 };

    State state;    // current state

    // Start is called before the first frame update
    void Start()
    {
        state = startingState;                      // the current state is the starting state
        textComponent.text = state.GetStateStory(); // the text displayed will be the starting state text
        //Debug.Log(oddNumbers[3]);

    }

    // Update is called once per frame
    void Update()
    {
        ManageState();
    }

    private void ManageState()
    {

        // Return what the next states are in an array
        var nextStates = state.getNextStates();     // var works the same as State[] here

        for (int i = 0; i < nextStates.Length; i++) // while index i is within the bounds of nextStates
        {
            if (Input.GetKeyDown(KeyCode.Alpha1+i))         // if player selects option
            {
                state = nextStates[i];                    // go to the selected state
            }
        }

        textComponent.text = state.GetStateStory(); // displays text from the next state

    }
}
