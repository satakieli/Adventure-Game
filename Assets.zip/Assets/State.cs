﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "State")]
public class State : ScriptableObject
{
    [TextArea(10,14)] [SerializeField] string storyText;
    // min inspector field size = 10 i.e. shows 10 lines
    // amount of lines before scroll = 14 i.e. expands to show 14 lines and then scrolls

    [SerializeField] State[] nextStates;

    public string GetStateStory()
    {
        return storyText;
    }

    public State[] getNextStates()
    {
        return nextStates;
    }

}
